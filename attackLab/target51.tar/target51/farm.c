/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_238(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_241(unsigned x)
{
    return x + 2496104776U;
}

unsigned addval_269(unsigned x)
{
    return x + 2425641092U;
}

unsigned getval_163()
{
    return 3347662980U;
}

void setval_303(unsigned *p)
{
    *p = 3284633928U;
}

unsigned getval_365()
{
    return 3281082471U;
}

unsigned getval_433()
{
    return 2445773128U;
}

void setval_145(unsigned *p)
{
    *p = 2425379010U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_225(unsigned *p)
{
    *p = 3223376269U;
}

void setval_297(unsigned *p)
{
    *p = 2446231834U;
}

unsigned getval_320()
{
    return 3677933961U;
}

unsigned getval_243()
{
    return 3526935177U;
}

unsigned getval_249()
{
    return 2497743176U;
}

void setval_434(unsigned *p)
{
    *p = 3687108233U;
}

unsigned getval_482()
{
    return 3767097421U;
}

void setval_160(unsigned *p)
{
    *p = 3385119113U;
}

void setval_481(unsigned *p)
{
    *p = 3385119113U;
}

void setval_472(unsigned *p)
{
    *p = 3674788233U;
}

unsigned addval_317(unsigned x)
{
    return x + 2425409165U;
}

void setval_319(unsigned *p)
{
    *p = 3223375369U;
}

void setval_170(unsigned *p)
{
    *p = 3372794509U;
}

void setval_343(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_331()
{
    return 2497743176U;
}

unsigned getval_219()
{
    return 3767101463U;
}

unsigned addval_368(unsigned x)
{
    return x + 2429649153U;
}

void setval_410(unsigned *p)
{
    *p = 2428668347U;
}

void setval_101(unsigned *p)
{
    *p = 3223372417U;
}

void setval_277(unsigned *p)
{
    *p = 3229142665U;
}

void setval_313(unsigned *p)
{
    *p = 3281047177U;
}

unsigned getval_497()
{
    return 3680551561U;
}

void setval_212(unsigned *p)
{
    *p = 3229929097U;
}

unsigned addval_462(unsigned x)
{
    return x + 3380924813U;
}

void setval_295(unsigned *p)
{
    *p = 2425406091U;
}

unsigned addval_426(unsigned x)
{
    return x + 3524838025U;
}

unsigned getval_338()
{
    return 3372274057U;
}

void setval_112(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_100()
{
    return 3525362312U;
}

unsigned getval_144()
{
    return 2447411528U;
}

void setval_300(unsigned *p)
{
    *p = 2430634312U;
}

unsigned addval_440(unsigned x)
{
    return x + 3525365449U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
